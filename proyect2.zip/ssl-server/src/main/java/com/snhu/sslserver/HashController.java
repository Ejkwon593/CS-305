package com.snhu.sslserver;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import java.security.MessageDigest;

@RestController
public class HashController {

    @GetMapping("/hash")
    public String getHash() {
        String input = "Hello Eddy Kwon!";  // your custom message
        StringBuilder hexString = new StringBuilder();

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());

            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
        } catch (Exception e) {
            return "Error computing hash: " + e.getMessage();
        }

        return "data:" + input + " : SHA-256 " + hexString.toString();
    }
}
